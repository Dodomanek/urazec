/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
import Modal from './Modal';
import { useUI, useUser } from '../lib/state';

export default function UserSettings() {
  const { name, info, setName, setInfo } = useUser();
  const { setShowUserConfig } = useUI();

  function updateClient() {
    setShowUserConfig(false);
  }

  return (
    <Modal onClose={() => setShowUserConfig(false)}>
      <div className="userSettings">
        <p>
          Tohle je jednoduchý nástroj, který ti umožní navrhovat, testovat a
          bavit se s vlastními AI postavami za chodu.
        </p>

        <form
          onSubmit={e => {
            e.preventDefault();
            setShowUserConfig(false);
            updateClient();
          }}
        >
          <p>Přidání těchto volitelných informací udělá zážitek zábavnějším:</p>

          <div>
            <p>Tvoje jméno</p>
            <input
              type="text"
              name="name"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="Jak ti mám říkat?"
            />
          </div>

          <div>
            <p>Tvoje informace</p>
            <textarea
              rows={3}
              name="info"
              value={info}
              onChange={e => setInfo(e.target.value)}
              placeholder="Věci, které bychom o tobě měli vědět… Co máš rád/a, co nemáš rád/a, koníčky, zájmy, oblíbené filmy, knihy, seriály, jídla atd."
            />
          </div>

          <button className="button primary">Jdeme na to!</button>
        </form>
      </div>
    </Modal>
  );
}
